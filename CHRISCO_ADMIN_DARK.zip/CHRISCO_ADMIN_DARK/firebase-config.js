const firebaseConfig = {
  apiKey: "AIzaSyAcXqSf_kvVR_a9hJcnlL69wTUtyFs01zU",
  authDomain: "chrisco-site.firebaseapp.com",
  projectId: "chrisco-site",
  storageBucket: "chrisco-site.firebasestorage.app",
  messagingSenderId: "491678385297",
  appId: "1:491678385297:web:862eb46270a2594f7eab30"
};
