const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));

app.post('/api/contact', (req, res) => {
  console.log('Contact reçu:', req.body);
  res.json({ok:true});
});

const port = process.env.PORT || 3000;
app.listen(port, ()=> console.log('Serveur CHRISCO en ligne sur le port', port));
